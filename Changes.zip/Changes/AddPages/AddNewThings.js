import React,{Component} from "react";
import Grid from '@material-ui/core/Grid';
import CardContent from '@material-ui/core/CardContent';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faEdit} from '@fortawesome/free-solid-svg-icons';
import CardActions from '@material-ui/core/CardActions';
import TextField from '@material-ui/core/TextField';
import FormControl from "@material-ui/core/FormControl";
import Button from "@material-ui/core/Button";
import Box from '@material-ui/core/Box';
import SaveIcon from '@material-ui/icons/Save';
import ListAltOutlinedIcon from '@material-ui/icons/ListAltOutlined';
import RotateLeftOutlinedIcon from '@material-ui/icons/RotateLeftOutlined';
import thingsService from "../services/things.service";
import Snackbar from '@material-ui/core/Snackbar';
import { IconButton } from '@material-ui/core';
import MuiAlert from "@material-ui/lab/Alert";



const style = {
  papersty: {
    minWidth: 275,
    backgroundColor:'#212121',
    marginTop: 20,
  },
  cardsty: {
    minWidth: 270,
    backgroundColor:'#fafafa',
    margin: 20
  }
}

function Alert(props) {
  return <MuiAlert elevation={6} variant="filled" {...props} />;
}

export default class AddNewThings extends Component {
  constructor(props){
    super(props);
    this.state ={
      title: '',
      description: '',
      owner: '',
      price: '',
      type: '',
      pet: '',
      imageUrl:'',
      message: null,
      snackbaropen: false,
      open: false
   }
   this.saveThing = this.saveThing.bind(this);
  }

  handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    this.setState({snackbaropen:false})
  };

  saveThing = (e) => {
   e.preventDefault();
   let thing = {title: this.state.title, description: this.state.description, owner: this.state.owner, price: this.state.price, type: this.state.type, pet: this.state.pet, imageUrl: this.state.imageUrl};
   thingsService.createPetProducts(thing)
       .then(res => {
          this.setState({snackbaropen:true, message:'Thing added successfully'})
           this.props.history.push('/thing');
       },
        (error)=>{
          this.setState({snackbaropen:true, message:'failed'})
        });
}

   onChange = (e) =>
       this.setState({ [e.target.name]: e.target.value });


   handleSubmit(event) {
       alert('A name was submitted: ' + this.state.value);
       event.preventDefault();
   }

  render(){

    return(
      <>
        <div>
          <Snackbar open={this.state.snackbaropen} autoHideDuration={3000} onClose={this.handleClose} anchorOrigin={{  vertical: 'top', horizontal: 'right'}}>
            <Alert onClose={this.handleClose} severity="success">
              {this.state.message}
            </Alert>
          </Snackbar>
        </div>

        <Grid container spacing={3}>
          <Grid item xs={1}/>
          <Grid item xs={10}>
          <form onSubmit={this.handleSubmit}>
            <Grid container>
              <Grid item xs={2}/>
              <Grid item xs={8}>
                <CardContent style={style.cardsty}>
                  <CardActions>
                    <CardContent>
                      <FontAwesomeIcon icon={faEdit}/>Add New Thing
                      <br/>
                      <br/>
                      <Grid container spacing={3}>

                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextField
                            required
                            id="title"
                            name="title"
                            label="Thing title"
                            helperText="Enter thing title"
                            variant="outlined"
                            value={this.state.title} 
                            onChange={this.onChange}
                          />
                        </FormControl>
                      </Grid>
                      
                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextField
                            required
                            id="description"
                            name="description"
                            label="Thing description"
                            helperText="Enter thing description"
                            variant="outlined"
                            value={this.state.description} 
                            onChange={this.onChange}
                          />
                        </FormControl>
                      </Grid>

                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextField
                            required
                            id="owner"
                            name="owner"
                            label="Thing owner"
                            helperText="Enter thing owner"
                            variant="outlined"
                            value={this.state.owner} 
                            onChange={this.onChange}
                          />
                        </FormControl>
                      </Grid>
                      
                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextField
                            required
                            id="price"
                            name="price"
                            label="Thing price"
                            helperText="Enter thing price"
                            variant="outlined"
                            value={this.state.price} 
                            onChange={this.onChange}
                          />
                        </FormControl>
                      </Grid>

                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextField
                            required
                            id="type"
                            name="type"
                            label="Thing type"
                            helperText="Enter thing type"
                            variant="outlined"
                            value={this.state.type} 
                            onChange={this.onChange}
                          />
                        </FormControl>
                      </Grid>
                      
                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextField
                            required
                            id="pet"
                            name="pet"
                            label="pet type"
                            helperText="Enter pet type"
                            variant="outlined"
                            value={this.state.pet} 
                            onChange={this.onChange}
                          />
                        </FormControl>
                      </Grid>

                      <Grid item xs={12}>
                        <FormControl fullWidth>
                          <TextField
                            required
                            id="imageUrl"
                            name="imageUrl"
                            label="Thing's imageUrl"
                            helperText="Enter thing imageUrl"
                            variant="outlined"
                            value={this.state.imageUrl} 
                            onChange={this.onChange}
                          />
                        </FormControl>
                      </Grid>

                      </Grid>
                    </CardContent>
                  </CardActions>
                  <CardActions>
                      <Box>
                        <Box ml={2}>
                        <FormControl>
                          <Button href="" variant="contained"
                          startIcon={<SaveIcon />}
                          onClick={this.saveThing}>
                            <span>Save</span>
                          </Button>
                        </FormControl>
                        </Box>
                      </Box>
                      <Box>
                        <Box ml={2}>
                        <FormControl>
                          <Button href="" variant="contained" 
                          startIcon={<RotateLeftOutlinedIcon />}>
                            <span>Reset</span>
                          </Button>
                        </FormControl>
                        </Box>
                      </Box>
                      <Box>
                        <Box ml={2}>
                        <FormControl>
                          <Button href="" variant="contained" 
                          startIcon={<ListAltOutlinedIcon />}>
                            <span>Things Lists</span>
                          </Button>
                        </FormControl>
                        </Box>
                      </Box>
                    </CardActions>
                </CardContent>
              </Grid>
              <Grid item xs={2}/>
            </Grid>
            </form>
          </Grid>
          <Grid item xs={1}/>
        </Grid>
      </>
    )
  }
}
