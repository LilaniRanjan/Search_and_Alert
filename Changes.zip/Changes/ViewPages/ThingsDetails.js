import React,{useEffect} from 'react';
import { makeStyles, Checkbox, Table, TableBody, TableCell, TableContainer, TableHead,InputAdornment, TableRow, Paper, Grid,InputBase,TextField, TableFooter} from '@material-ui/core';
import SearchIcon from '@material-ui/icons/Search';
import AddBoxIcon from '@material-ui/icons/AddBox';
import DeleteIcon from '@material-ui/icons/Delete';
import EditIcon from '@material-ui/icons/Edit';
import { IconButton } from '@material-ui/core';
import thingsService from "../services/things.service";
import TablePagination from '@material-ui/core/TablePagination';
import FirstPageIcon from '@material-ui/icons/FirstPage';
import KeyboardArrowLeft from '@material-ui/icons/KeyboardArrowLeft';
import KeyboardArrowRight from '@material-ui/icons/KeyboardArrowRight';
import LastPageIcon from '@material-ui/icons/LastPage';
import {  useTheme } from '@material-ui/core/styles';
import Snackbar from '@material-ui/core/Snackbar';
import MuiAlert from "@material-ui/lab/Alert";
import axios from 'axios';
import ClearIcon from '@material-ui/icons/Clear';

const useStyles1 = makeStyles((theme) => ({
    root: {
      flexShrink: 0,
      marginLeft: theme.spacing(2.5),
    },
  }));

const useStyles = makeStyles({
  table: {
    minWidth: 650,
  },
  grid: {
      margin: '35px 150px 20px 50px',
      padding: '10px 10px 10px 10px',
      backgroundColor: "#424242"
  },
  paper: {
    padding: '10px 10px 10px 10px', 
    margin: '10px 10px 10px 10px',
    position: 'inherit'
  },
  search: {
    position: 'top',
    align:'left',
    },
});

function Alert(props) {
    return <MuiAlert elevation={6} variant="filled" {...props} />;
  }


function TablePaginationActions(props) {
    const classes = useStyles1();
    const theme = useTheme();
    const { count, page, rowsPerPage, onChangePage } = props;
  
    const handleFirstPageButtonClick = (event) => {
      onChangePage(event, 0);
    };
  
    const handleBackButtonClick = (event) => {
      onChangePage(event, page - 1);
    };
  
    const handleNextButtonClick = (event) => {
      onChangePage(event, page + 1);
    };
  
    const handleLastPageButtonClick = (event) => {
      onChangePage(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1));
    };
  
    return (
      <div className={classes.root}>
        <IconButton
          onClick={handleFirstPageButtonClick}
          disabled={page === 0}
          aria-label="first page"
        >
          {theme.direction === 'rtl' ? <LastPageIcon /> : <FirstPageIcon />}
        </IconButton>
        <IconButton onClick={handleBackButtonClick} disabled={page === 0} aria-label="previous page">
          {theme.direction === 'rtl' ? <KeyboardArrowRight /> : <KeyboardArrowLeft />}
        </IconButton>
        <IconButton
          onClick={handleNextButtonClick}
          disabled={page >= Math.ceil(count / rowsPerPage) - 1}
          aria-label="next page"
        >
          {theme.direction === 'rtl' ? <KeyboardArrowLeft /> : <KeyboardArrowRight />}
        </IconButton>
        <IconButton
          onClick={handleLastPageButtonClick}
          disabled={page >= Math.ceil(count / rowsPerPage) - 1}
          aria-label="last page"
        >
          {theme.direction === 'rtl' ? <FirstPageIcon /> : <LastPageIcon />}
        </IconButton>
      </div>
    );
  }
  



function ThingsData(id, username, email,  role) {
  return {id, username, email, role };
}

const rows = [
  ThingsData('id1', 'uaername', '@mail',  'admin'),
  ThingsData('id2', 'username',  '@mail',  'user'),
  ThingsData('id2', 'username',  '@mail',  'admin'),
 
  
];

export default function ThingsDetails() {
  const classes = useStyles();

  const [thing, setThing] = React.useState([])
  const [count, setCount] = React.useState(0)
  const [rowsPerPage, setRowsPerPage] = React.useState(5);
  const [page, setPage] = React.useState(0);
  const [message, setMessage] = React.useState('')
  const [open, setOpen] = React.useState(false);
  const [searchString, setSearchString]= React.useState('');


  const serachData = () => {
    setPage(0)
    console.log('Hiiiiiiiiiii');
    if(searchString == ''){
      console.log('Helloooooo');
      thingsService.getAllThingsInPage(0, 5, 'id')
      .then((response) => {
        setCount (response.data.Total_No_Of_Elements)
        console.log(count)
        
        setThing ( response.data.data)
        console.log(thing)
    })
    }else{
      console.log('Welcomeeeeeee');
      // pharmacyService.getSearchMedicine(0, 5, 'id', searchString)
      console.log(page);
      console.log(count);
      console.log(searchString);
      axios.get("http://localhost:8080/petProducts?pageNo=" + page + "&pageSize=" + count + "&sortBy=id" + "&searchText=" + searchString)
      .then((response) => {
        setCount (response.data.Total_No_Of_Elements)
        console.log(count)
        setThing( response.data.data)
      console.log(thing)
    })
  }
}


  useEffect(() => {

    thingsService.getAllThingsInPage(0, 5, 'id')

    .then(
      response => {
        console.log(response.data.data)
        setThing(response.data.data)
        setCount(response.data.Total_No_Of_Elements)
        console.log(response.data)
      },
      error => {
        console.log(error)
        setThing(
          (error.response && error.response.data) ||
            error.message ||
            error.toString()
        )
      }
    );
  }, [])

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
    thingsService.getAllThingsInPage(newPage,5, 'id')
        .then((res)=>{
            setThing(res.data.data)
          setCount(res.data.Total_No_Of_Elements)
          console.log(res.data)
        },
        (error)=>{
          setCount(error)
        });
  };


  const searchChange = (e) => {
    console.log(e.target.value)
    setSearchString(e.target.value)
  }

  const deleteProductById = (Id) =>{
    thingsService.deleteProductById(Id)
       .then(response => {
        setMessage('User deleted successfully.');
        setOpen(true)
        // window.location.reload()
        setThing(thing.filter(thing => thing.id !== Id));
       },
       (error)=>{
        setMessage('deleted fail.')
        setOpen(true)
       });
       
       
  }
  
  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpen(false);
  };

  const clearText = (e) => {
    setSearchString ('')
    thingsService.getAllThingsInPage(0,5, 'id')
    .then((response) => {
    console.log(response.data.Total_No_Of_Elements)
    setCount (response.data.Total_No_Of_Elements)
    console.log(count)
    setThing ( response.data.data)
    console.log(page)
    console.log(thing)
    //console.log(Response.data.data)
    
  })
}
  
  return (
      <div>
    <Grid className={classes.grid}>
      <Paper className = {classes.paper}>

      <div>
        <Snackbar 
          open={open} 
          autoHideDuration={6000} 
          onClose={handleClose} 
          anchorOrigin={{  vertical: 'top', horizontal: 'right'}}
        >
          <Alert onClose={handleClose} severity="error">
            {message}
          </Alert>
        </Snackbar>
      </div>

        <h1>ThingsDetails</h1>
        <div className={classes.search}>
            <div className={classes.searchIcon} style = {{float: 'right'}}>
            
            
            
            <TextField
              // className={classes.margin}
              id="input-with-icon-textfield"
              label="Search"
              value = {searchString}
              onChange = {searchChange}
              
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <IconButton onClick = {() => serachData()}>
                      <SearchIcon/>
                    </IconButton>
                  </InputAdornment>
                ),
                endAdornment : (
                  <InputAdornment position="end">
                    <IconButton onClick = {() => clearText()}>
                      <ClearIcon/>
                    </IconButton>
                  </InputAdornment>
                )
              }}
            />
              
            </div>
        </div>
        
        <TableContainer>
      <Table className={classes.table} size="small">
        <TableHead>
          <TableRow>
          <TableCell align="left"><b>Actions</b></TableCell>
            <TableCell align="left"><b>Title</b></TableCell>
            <TableCell align="left"><b>Description</b></TableCell>
            <TableCell align="left"><b>Owner</b></TableCell>
            <TableCell align="left"><b>Price</b></TableCell>
            <TableCell align="left"><b>Type</b></TableCell>
            <TableCell align="left"><b>Pet</b></TableCell>
            
          </TableRow>
        </TableHead>
        <TableBody>
          {thing.map((row) => (
            <TableRow>
              
              <TableCell>
              
              <IconButton>
              <DeleteIcon
                color="default"
                align="left"
                inputProps={{ 'aria-label': 'DeleteIcon with default color' }}
                onClick={() =>deleteProductById(row.id)}
              />
              </IconButton>

              <IconButton href ={ `/thing${row.id}`}  >
                <EditIcon
                color="default"
                align="left"
                inputProps={{ 'aria-label': 'DeleteIcon with default color' }}
              />
              </IconButton>

              </TableCell>
              <TableCell align="left">{row.title}</TableCell>
              <TableCell align="left">{row.description}</TableCell>
              <TableCell align="left">{row.owner}</TableCell>
              <TableCell align="left">{row.price}</TableCell>
              <TableCell align="left">{row.type}</TableCell>
              <TableCell align="left">{row.pet}</TableCell>
              
            </TableRow>
          ))}
          
        </TableBody>
        <TableFooter>
        <TableRow>
            <TablePagination
              rowsPerPageOptions={[5]}
              //colSpan={3}
              count={count}
              rowsPerPage={rowsPerPage}
              page={page}
              // SelectProps={{
              //   inputProps: { 'aria-label': 'rows per page' },
              //   native: true,
              // }}
              onChangePage={handleChangePage}
              // onChangeRowsPerPage={handleChangeRowsPerPage}
              ActionsComponent={TablePaginationActions}
            />
          </TableRow>
        </TableFooter>
      </Table>

     
    </TableContainer>

    
    
      </Paper>
    </Grid>
    </div>
  );
}