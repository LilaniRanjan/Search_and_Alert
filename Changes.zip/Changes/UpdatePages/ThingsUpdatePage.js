import React,{Component} from "react";
import Grid from '@material-ui/core/Grid';
import CardContent from '@material-ui/core/CardContent';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faEdit} from '@fortawesome/free-solid-svg-icons';
import CardActions from '@material-ui/core/CardActions';
import TextField from '@material-ui/core/TextField';
import FormControl from "@material-ui/core/FormControl";
import Button from "@material-ui/core/Button";
import Box from '@material-ui/core/Box';
import SaveIcon from '@material-ui/icons/Save';
import ListAltOutlinedIcon from '@material-ui/icons/ListAltOutlined';
import { Alert} from '@material-ui/lab';
import RotateLeftOutlinedIcon from '@material-ui/icons/RotateLeftOutlined';
import thingsService from "../services/things.service";
import Snackbar from '@material-ui/core/Snackbar';



const style = {
  papersty: {
    minWidth: 275,
    backgroundColor:'#212121',
    marginTop: 20,
  },
  cardsty: {
    minWidth: 270,
    backgroundColor:'#fafafa',
    margin: 20
  }
}

export default class ThingsUpdatePage extends Component {
  constructor(props){
    super(props);
    this.state ={
        id:'',
        title: '',
        imageUrl: '',
        description: '',
        owner: '',
        price: '',
        type: '',
        pet:'',
        message: null,
        snackbaropen: false,
        open: false
   }
   this.saveThing = this.saveThing.bind(this);
   this.loadThingProduct = this.loadThingProduct.bind(this);
  }

  componentDidMount() {
    const id = this.props.match.params.id;
    console.log(id);
    if(id) {
      this.loadThingProduct(id);
    }
    // console.log(this.match.props.id)
  }
  loadThingProduct =(id) =>{
    thingsService.getProductById(id) 
    .then((res) => {
      let Product = res.data;
      this.setState({
        id:Product.id,
        title: Product.title,
        imageUrl: Product.imageUrl,
        description: Product.description,
        owner: Product.owner,
        price: Product.price,
        type: Product.type,
        pet: Product.pet,
      })
             

    });

  }

  handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    this.setState({snackbaropen:false})
  };


  saveThing = (e) => {
    e.preventDefault();
    let product = {title: this.state.title, imageUrl: this.state.imageUrl, description: this.state.description, owner: this.state.owner, price: this.state.price, type: this.state.type, pet: this.state.pet};
    thingsService.updateProduct(this.state.id, product)
        .then(res => {
          console.log(res);
          this.setState({snackbaropen:true, message:'Product update successfully'})
          setTimeout(()=> this.productList(), 3000)
        })
        .catch(error => {
          console.log(error);
          this.setState({snackbaropen:true, message:'fail'})
        });
}

   onChange = (e) =>
       this.setState({ [e.target.name]: e.target.value });


   handleSubmit(event) {
       alert('A name was submitted: ' + this.state.value);
       event.preventDefault();
   }

   productList =()=>{
    return this.props.history.push('/thing');
  }

  render(){

    return(
      <>

        <div>
          <Snackbar open={this.state.snackbaropen} autoHideDuration={3000} onClose={this.handleClose} anchorOrigin={{  vertical: 'top', horizontal: 'right'}}>
            <Alert onClose={this.handleClose} severity="success">
              {this.state.message}
            </Alert>
          </Snackbar>
        </div>

        <Grid container spacing={3}>
          <Grid item xs={1}/>
          <Grid item xs={10}>
          <form onSubmit={this.handleSubmit}>
            <Grid container>
              <Grid item xs={2}/>
              <Grid item xs={8}>
                <CardContent style={style.cardsty}>
                  <CardActions>
                    <CardContent>
                      <FontAwesomeIcon icon={faEdit}/>Add New Thing
                      <br/>
                      <br/>
                      <Grid container spacing={3}>

                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextField
                            required
                            id="title"
                            name="title"
                            label="Thing title"
                            helperText="Enter thing title"
                            variant="outlined"
                            value={this.state.title} 
                            onChange={this.onChange}
                          />
                        </FormControl>
                      </Grid>
                      
                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextField
                            required
                            id="description"
                            name="description"
                            label="Thing description"
                            helperText="Enter thing description"
                            variant="outlined"
                            value={this.state.description} 
                            onChange={this.onChange}
                          />
                        </FormControl>
                      </Grid>

                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextField
                            required
                            id="owner"
                            name="owner"
                            label="Thing owner"
                            helperText="Enter thing owner"
                            variant="outlined"
                            value={this.state.owner} 
                            onChange={this.onChange}
                          />
                        </FormControl>
                      </Grid>
                      
                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextField
                            required
                            id="price"
                            name="price"
                            label="Thing price"
                            helperText="Enter thing price"
                            variant="outlined"
                            value={this.state.price} 
                            onChange={this.onChange}
                          />
                        </FormControl>
                      </Grid>

                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextField
                            required
                            id="type"
                            name="type"
                            label="Thing type"
                            helperText="Enter thing type"
                            variant="outlined"
                            value={this.state.type} 
                            onChange={this.onChange}
                          />
                        </FormControl>
                      </Grid>
                      
                      <Grid item xs={12} sm={6}>
                        <FormControl fullWidth>
                          <TextField
                            required
                            id="pet"
                            name="pet"
                            label="pet type"
                            helperText="Enter pet type"
                            variant="outlined"
                            value={this.state.pet} 
                            onChange={this.onChange}
                          />
                        </FormControl>
                      </Grid>

                      <Grid item xs={12}>
                        <FormControl fullWidth>
                          <TextField
                            required
                            id="imageUrl"
                            name="imageUrl"
                            label="Thing's imageUrl"
                            helperText="Enter thing imageUrl"
                            variant="outlined"
                            value={this.state.imageUrl} 
                            onChange={this.onChange}
                          />
                        </FormControl>
                      </Grid>

                      </Grid>
                    </CardContent>
                  </CardActions>
                  <CardActions>
                      <Box>
                        <Box ml={2}>
                        <FormControl>
                          <Button href="" variant="contained"
                          startIcon={<SaveIcon />}
                          onClick={this.saveThing}>
                            <span>Save</span>
                          </Button>
                        </FormControl>
                        </Box>
                      </Box>
                      <Box>
                        <Box ml={2}>
                        <FormControl>
                          <Button href="" variant="contained" 
                          startIcon={<RotateLeftOutlinedIcon />}>
                            <span>Reset</span>
                          </Button>
                        </FormControl>
                        </Box>
                      </Box>
                      <Box>
                        <Box ml={2}>
                        <FormControl>
                          <Button href="" variant="contained" 
                          startIcon={<ListAltOutlinedIcon />}>
                            <span>Things Lists</span>
                          </Button>
                        </FormControl>
                        </Box>
                      </Box>
                    </CardActions>
                </CardContent>
              </Grid>
              <Grid item xs={2}/>
            </Grid>
            </form>
          </Grid>
          <Grid item xs={1}/>
        </Grid>
      </>
    )
  }
}
